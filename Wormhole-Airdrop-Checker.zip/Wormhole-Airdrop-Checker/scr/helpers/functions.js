const fs = require('fs')
const chalk = require('chalk')

module.exports = function () {
	this.log = function (log) {
		let time = `${chalk.green(`${chalk.magenta('[')}${new Date(Date.now()).getDate() < 10 ? `0${new Date(Date.now()).getDate()}` : new Date(Date.now()).getDate()}-${new Date(Date.now()).getMonth() + 1 < 10 ? `0${new Date(Date.now()).getMonth() + 1}` : new Date(Date.now()).getMonth() + 1}-${new Date(Date.now()).getFullYear()}`)} ${chalk.green(`${new Date(Date.now()).getHours() < 10 ? `0${new Date(Date.now()).getHours()}` : new Date(Date.now()).getHours()}:${new Date(Date.now()).getMinutes() < 10 ? `0${new Date(Date.now()).getMinutes()}` : new Date(Date.now()).getMinutes()}:${new Date(Date.now()).getSeconds() < 10 ? `0${new Date(Date.now()).getSeconds()}` : new Date(Date.now()).getSeconds()}`)}${chalk.magenta(']')}`
		console.log(time, log)
	}

	this.getFunctionName = function () {
		let error = new Error()
		error.from = function (n = 0) {
			return this.stack.split('at ')[++n].split(' ')[0]
		}
		return error.from(1)
	}

	this.delay = function (ms = 1000) {
		return new Promise((resolve) => setTimeout(resolve, ms))
	}

	this.saveJSON = function (path, func) {
		fs.writeFileSync(`${path.includes(`.json`) ? path : `${path}.json`}`, JSON.stringify(func, null, 4), 'utf-8')
	}

	this.readJSON = function (path) {
		return JSON.parse(fs.readFileSync(`${path.includes(`.json`) ? path : `${path}.json`}`))
	}

	this.readTXT = function (path) {
		return fs.readFileSync(path, { encoding: 'utf-8' }).split(/\r?\n/)
	}

	this.timestamp = function () {
		return Math.floor(Date.now() / 1000)
	}

	this.getRandomProxy = function () {
		const proxy_list = fs.readFileSync('./src/data/proxies.txt', { encoding: 'utf-8' }).split(/\r?\n/)
		return proxy_list[Math.floor(Math.random() * proxy_list.length)]
	}

	this.getTimeModify = function (timestamp) {
		let d = new Date(timestamp * 1000)

		let year = d.getFullYear()
		let month = d.getMonth() + 1 < 10 ? `0${d.getMonth() + 1}` : d.getMonth() + 1
		let day = d.getDate() < 10 ? `0${d.getDate()}` : d.getDate()
		let hours = d.getHours() < 10 ? `0${d.getHours()}` : d.getHours()
		let minutes = d.getMinutes() < 10 ? `0${d.getMinutes()}` : d.getMinutes()
		let seconds = d.getSeconds() < 10 ? `0${d.getSeconds()}` : d.getSeconds()

		return `${day}.${month}.${year}, ${hours}:${minutes}:${seconds}`
	}
}
