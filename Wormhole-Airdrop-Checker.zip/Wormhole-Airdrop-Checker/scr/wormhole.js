require('./helpers/functions.js')()

const requests = require('./helpers/requests.js')
const chalk = require('chalk')
const fs = require('fs')

let wallets = readTXT('./src/wormhole.txt')

let counts = 0
let checked = 0

let DB = {}

main()

async function main() {
	let promises = []

	log(chalk.yellow(`Got ${wallets.length} Address`))

	console.log(wallets.length)

	for (let address of wallets) {
		let res = checkEligibity(address)
		promises.push(res)
		await delay(25)
	}

	await Promise.all(promises)

	log(chalk.green(`Eligible Wallets: ${counts} | Checked: ${checked}`))
}

async function checkEligibity(address) {
	process.stdout.write(`\rChecked ${checked}/${wallets.length}`)
	let data = {
		method: 'GET',
		url: `https://prod-flat-files-min.wormhole.com/${address}_1.json`,
		retries: 6,
		timeout: 2500,
		request_retry_delay_ms: 2500,
	}

	const res = await requests.doRequest(data)

	if (res.status != true) {
		if (res.msg == `not elligible`) {
			delete DB[address]
			saveJSON('DB.json', DB)
			checked++
			return
		}

		return log(chalk.red(`${address} - ${res.msg}`))
	}

	if (res.data) {
		let message = `${res.data.address}:${res.data.amount / 1e9}`
		log(chalk.green(message))
		counts++
		fs.appendFileSync(`./src/wormhole_result.txt`, `${message}\n`, 'utf-8')
	}
	checked++
}
